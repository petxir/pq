#!/bin/sh

./xmrig --coin zephyr --url "zeph.kryptex.network:7030" --user ZEPHYR2mpCMNRAufwuVQALEeb9bBZgAujTEGMcec5nbVa5h9H777rmVABUE5DMUGYLHmsJEVSBHWbYF2GcngXY5vZR5geixiYue2x/MyFirstRig -p x -k